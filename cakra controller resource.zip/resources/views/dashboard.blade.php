@extends('layout.layout')
{{-- @section('content')
   <div class="content no-padding-bottom">
      <div class="row">
         <div class="col-md-12">
            <div class="panel panel-white">
               <div class="panel-heading">
                  <h6 class="panel-title text-semibold">Semibold headings</h6>
                  <div class="heading-elements">
                     <ul class="icons-list">
                        <li><a data-action="collapse"></a></li>
                     </ul>
                  </div>
               </div>

               <div class="panel-body">
                  <div class="content-group-sm">
                     <h1 class="no-margin text-semibold">H1 Heading <small>Semibold 25px</small></h1>
                  </div>

                  <div class="content-group-sm">
                     <h2 class="no-margin text-semibold">H2 Heading <small>Semibold 23px</small></h2>
                  </div>

                  <div class="content-group-sm">
                     <h3 class="no-margin text-semibold">H3 Heading <small>Semibold 21px</small></h3>
                  </div>

                  <div class="content-group-sm">
                     <h4 class="no-margin text-semibold">H4 Heading <small>Semibold 19px</small></h4>
                  </div>

                  <div class="content-group-sm">
                     <h5 class="no-margin text-semibold">H5 Heading <small>Semibold 17px</small></h5>
                  </div>

                  <div class="content-group-sm">
                     <h6 class="no-margin text-semibold">H6 Heading <small>Semibold 15px</small></h6>
                  </div>
               </div>
            </div>
         </div>
      </div>
	  @include('layout.footer')
    


   </div>
@endsection --}}
