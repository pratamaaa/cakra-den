<?php

namespace App\Imports;

use App\Models\User;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use Maatwebsite\Excel\Concerns\WithCalculatedFormulas;
use Maatwebsite\Excel\Concerns\HasReferencesToOtherSheets;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithStartRow;
use App\Models\Trx_work_programs;
use Illuminate\Support\Facades\DB;
use App\Helpers\GlobalHelper;
use Illuminate\Support\Str;
use App\Models\Mst_work_units;
use App\Models\Trx_budgets;
use App\Models\View_work_program_parent;
use Maatwebsite\Excel\Concerns\ToArray;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\SkipsOnError;

class PerbagianImport implements ToArray, HasReferencesToOtherSheets, WithCalculatedFormulas, WithStartRow, WithMultipleSheets, SkipsEmptyRows
{
    public function sheets(): array
    {

        // return [
        //     3 => $this,
        //     6 => new RealisasiBelanjaImport($this->year, $this->month, $this->document_type),
        // ];
       
        return [
            3 => $this
        ];
    }
        
    public function startRow(): int
    {
        return 3;
    }
    public function array($row)
    {
        echo '<pre>';
        print_r($row);
        die();
        // echo '<pre>';
        // print_r($row);
        // die();
    }
}
