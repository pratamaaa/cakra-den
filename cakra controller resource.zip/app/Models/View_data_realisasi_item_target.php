<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class View_data_realisasi_item_target extends Model
{
    protected $table        = 'view_data_realisasi_item_target';

    const UPDATED_AT        = null;
    const CREATED_AT        = null;
}
