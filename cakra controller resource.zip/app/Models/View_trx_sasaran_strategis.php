<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class View_trx_sasaran_strategis extends Model
{
    protected $table        = 'view_trx_sasaran_strategis';
    protected $primaryKey   = 'dashboard_realisasi_id';
    const UPDATED_AT        = null;
    const CREATED_AT        = null;
}