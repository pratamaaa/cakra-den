<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class view_trx_dashboard_realisasi extends Model
{
    protected $table        = 'View_trx_dashboard_realisasi';
    protected $primaryKey   = 'dashboard_realisasi_id';
    const UPDATED_AT        = null;
    const CREATED_AT        = null;
}