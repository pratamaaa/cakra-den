<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Trx_exam_period extends Model
{
    protected $table        = 'trx_exam_period';
    protected $primaryKey   = 'exam_period_id';

    const UPDATED_AT        = null;
    const CREATED_AT        = null;
}