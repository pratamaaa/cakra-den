<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class View_trx_sasaran_strategis extends Model
{
    protected $table        = 'view_trx_sasaran_strategis';
    protected $primaryKey   = 'sasaran_strategis_id';
    const UPDATED_AT        = null;
    const CREATED_AT        = null;
}