<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Mst_work_units extends Model
{
    protected $table        = 'mst_work_units';
    protected $primaryKey   = 'work_unit_id';
    const UPDATED_AT        = null;
    const CREATED_AT        = null;
}