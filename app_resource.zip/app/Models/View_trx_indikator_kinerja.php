<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class View_trx_indikator_kinerja extends Model
{
    protected $table        = 'view_trx_indikator_kinerja';
    protected $primaryKey   = 'indikator_kinerja_id';
    const UPDATED_AT        = null;
    const CREATED_AT        = null;
}