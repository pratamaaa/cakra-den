<div class="sidebar-section">
   {!! $site_menu !!}
</div>