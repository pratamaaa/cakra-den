<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class View_data_realisasi_item_sppd extends Model
{
    protected $table        = 'view_data_realisasi_item_sppd';

    const UPDATED_AT        = null;
    const CREATED_AT        = null;
}
