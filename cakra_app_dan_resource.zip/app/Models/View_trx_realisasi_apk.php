<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class View_trx_realisasi_apk extends Model
{
    protected $table        = 'view_trx_realisasi_apk';
    protected $primaryKey   = 'realisasi_apk_id';
    const UPDATED_AT        = null;
    const CREATED_AT        = null;
}