<div class="navbar navbar-sm navbar-footer border-top">
   <div class="container-fluid text-center">
      <span class="col-md-12"><a href="{{ env('COPYRIGHT_URL') }}" target="_blank">{{ env('COPYRIGHT') }}</a></span>

   </div>
</div>